DOMAIN = "tplink_mr200"
DEFAULT_HOST = "192.168.3.1"
DEFAULT_USERNAME = "admin"

CONF_HOST = "host"
CONF_PASSWORD = "password"

UPDATE_INTERVAL = 30  # seconds
