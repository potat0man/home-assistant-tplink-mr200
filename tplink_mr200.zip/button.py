from homeassistant.components.button import ButtonEntity
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.config_entries import ConfigEntry

from .const import DOMAIN

async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up buttons."""
    client = hass.data[DOMAIN][config_entry.entry_id]["client"]
    coordinator = hass.data[DOMAIN][config_entry.entry_id]["coordinator"]

    async_add_entities([RebootButton(coordinator, client)])

class RebootButton(ButtonEntity):
    """Representation of a reboot button."""

    def __init__(self, coordinator, client):
        self._client = client
        self._coordinator = coordinator
        self._attr_unique_id = f"tplink_mr200_reboot"
        device_info = coordinator.data.get("device_info", {})
        device_name = device_info.get("model", "").lower().replace(" ", "_")
        self.entity_id = f"button.{device_name}_reboot"
        self._attr_name = "Reboot"

    @property
    def device_info(self):
        """Return device info."""
        device_info = self._coordinator.data.get("device_info", {})
        return {
            "identifiers": {(DOMAIN, "tplink_mr200")},
            "name": "TP-Link MR200",
            "manufacturer": device_info.get("manufacturer"),
            "model": device_info.get("model"),
            "hw_version": device_info.get("hw_version"),
            "sw_version": device_info.get("sw_version"),
        }

    async def async_press(self) -> None:
        """Handle the button press."""
        await self.hass.async_add_executor_job(self._client.reboot)
